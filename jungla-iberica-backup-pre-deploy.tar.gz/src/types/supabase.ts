Need to install the following packages:
supabase@2.45.5
Ok to proceed? (y) 