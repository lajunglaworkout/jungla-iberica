import { Handler } from '@netlify/functions';
import Anthropic from '@anthropic-ai/sdk';

export const handler: Handler = async (event) => {
  // Solo permitir POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    // Parsear el body
    const { transcript, meetingTitle, participants } = JSON.parse(event.body || '{}');

    if (!transcript) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Transcript is required' })
      };
    }

    // Obtener API key de Anthropic
    // Intentar varias variables de entorno comunes
    const apiKey = process.env.ANTHROPIC_API_KEY ||
      process.env.VITE_ANTHROPIC_API_KEY ||
      process.env.REACT_APP_ANTHROPIC_API_KEY;

    console.log('🔑 Verificando Anthropic API key:', apiKey ? '✅ Encontrada' : '❌ No encontrada');

    if (!apiKey) {
      console.error('❌ Anthropic API key no configurada');
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'Anthropic API key not configured' })
      };
    }

    // Inicializar SDK
    const anthropic = new Anthropic({
      apiKey: apiKey,
    });

    // Crear el prompt
    const prompt = `Eres un asistente experto en generar actas de reuniones profesionales en español.

ANALIZA esta transcripción y genera un acta estructurada:

=== TRANSCRIPCIÓN ===
${transcript.substring(0, 15000)}
=== FIN TRANSCRIPCIÓN ===

REUNIÓN:
- Título: ${meetingTitle || 'Reunión'}
- Participantes: ${participants?.join(', ') || 'No especificados'}
- Fecha: ${new Date().toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' })}

GENERA un acta profesional con:
1. RESUMEN: Breve resumen de lo tratado (2-3 líneas)
2. PUNTOS IMPORTANTES: Lista de los temas más relevantes
3. TAREAS ASIGNADAS: Extrae cada tarea con responsable y fecha límite
4. VALORACIÓN: Evaluación general de la reunión

RESPONDE SOLO con este JSON (sin markdown, sin \`\`\`json):
{
  "minutes": "# Acta de Reunión\\n\\n**${meetingTitle || 'Reunión'}**\\n**Fecha:** ${new Date().toLocaleDateString('es-ES')}\\n**Participantes:** ${participants?.join(', ') || 'No especificados'}\\n\\n## Resumen\\n[resumen aquí]\\n\\n## Puntos Importantes\\n- [punto 1]\\n- [punto 2]\\n\\n## Valoración\\n[valoración aquí]",
  "tasks": [
    {"title": "Título tarea", "assignedTo": "Nombre", "deadline": "YYYY-MM-DD", "priority": "media"}
  ]
}`;

    console.log('🤖 Llamando a Claude API (SDK)...');

    const message = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 4000,
      temperature: 0.3,
      messages: [
        {
          role: "user",
          content: prompt
        }
      ]
    });

    console.log('📥 Respuesta de Claude recibida');

    // Extraer contenido de texto
    const contentBlock = message.content[0];
    if (contentBlock.type !== 'text') {
      throw new Error('La respuesta de Claude no es texto');
    }
    const content = contentBlock.text;

    console.log('📄 Contenido:', content.substring(0, 200) + '...');

    // Parseo robusto
    let result;
    try {
      const cleanContent = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      result = JSON.parse(cleanContent);
    } catch (e1) {
      console.log('⚠️ Parseo directo falló, intentando regex...');
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        console.error('❌ No se encontró JSON en la respuesta:', content);
        return {
          statusCode: 500,
          body: JSON.stringify({ error: 'No se pudo extraer JSON de la respuesta de Claude' })
        };
      }
      result = JSON.parse(jsonMatch[0]);
    }

    // Validar respuesta
    if (!result.minutes || !result.tasks) {
      console.error('❌ Respuesta inválida:', result);
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'La respuesta no tiene el formato esperado' })
      };
    }

    console.log('✅ Acta generada correctamente');
    console.log('📋 Tareas extraídas:', result.tasks.length);

    // Devolver respuesta exitosa
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*', // Permitir CORS
        'Access-Control-Allow-Headers': 'Content-Type'
      },
      body: JSON.stringify({
        success: true,
        minutes: result.minutes,
        tasks: result.tasks
      })
    };

  } catch (error) {
    console.error('❌ Error en función:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Error desconocido'
      })
    };
  }
};
